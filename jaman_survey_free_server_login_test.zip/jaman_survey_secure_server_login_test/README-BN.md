# জামান সার্ভে — ফ্রি সার্ভার লগইন পরীক্ষামূলক সেটআপ

এই প্যাকেজটি আলাদা পরীক্ষামূলক কপি। এটি আপনার লাইভ ওয়েবসাইট, ডোমেইন বা DNS পরিবর্তন করে না।

## কী কী সার্ভার-সুরক্ষিত
- `/private/a4` — A4 রিপোর্ট; লগইন ছাড়া সার্ভার ফাইলটি পাঠায় না।
- `/private/admin` — ব্যক্তিগত অ্যাডমিন প্রবেশদ্বার। এটি এখনো পুরোনো Local Storage সেটিংস এডিটরের পূর্ণ বিকল্প নয়।
- পাসওয়ার্ড bcrypt hash আকারে যাচাই হয়; মূল পাসওয়ার্ড কোডে রাখা হয় না।
- সেশন Neon PostgreSQL-এ থাকে; Render-এর অস্থায়ী ফাইল সিস্টেমে SQLite রাখা হয়নি।
- CSRF token, same-origin যাচাই, login rate limit, Helmet, HttpOnly/SameSite cookie এবং ৩০ মিনিটের idle timeout আছে।

## ফ্রি হোস্টিংয়ের প্রস্তাবিত জোড়া
1. **GitHub Free** — কোডের private repository।
2. **Neon Free** — PostgreSQL ডেটাবেস ও লগইন সেশন।
3. **Render Free Web Service** — Node.js সার্ভার। Render ফ্রি সার্ভিসে ১৫ মিনিট নিষ্ক্রিয় থাকলে sleep হতে পারে; পরের ভিজিটে জাগতে প্রায় এক মিনিট লাগতে পারে।

ফ্রি প্ল্যানের সীমা পরিবর্তন হতে পারে। এটি পরীক্ষামূলক ব্যবহারের জন্য; গুরুত্বপূর্ণ গ্রাহক তথ্য বা উৎপাদন-পর্যায়ের নির্ভরযোগ্যতার জন্য নয়।

## ধাপ ১ — GitHub-এ Private repository তৈরি
1. https://github.com/ এ অ্যাকাউন্ট খুলুন/লগইন করুন।
2. **New repository** চাপুন।
3. নাম দিন `jaman-survey-private-test`।
4. **Private** নির্বাচন করুন; Public নয়।
5. এই ZIP Extract করে ভেতরের সব ফাইল repository-তে upload করুন। `.env` বা কোনো আসল পাসওয়ার্ড upload করবেন না। `.gitignore`-এ `.env` বাদ দেওয়া আছে।

## ধাপ ২ — Neon-এ ফ্রি PostgreSQL তৈরি
1. https://neon.com/ এ সাইন আপ করুন।
2. **Create project** করে নাম দিন `jaman-survey-test`।
3. Dashboard থেকে **Connection string** কপি করুন। Pooled connection string হলে ভালো।
4. নিশ্চিত করুন URL-এ `sslmode=require` আছে। এটি গোপন রাখুন; কাউকে পাঠাবেন না।

## ধাপ ৩ — অ্যাডমিন পাসওয়ার্ড hash তৈরি
আপনার কম্পিউটারে Node.js 20+ থাকলে Extract করা ফোল্ডারে Terminal খুলে চালান:

```bash
npm install
npm run hash-password
```

কমপক্ষে ১২ অক্ষরের শক্তিশালী পাসওয়ার্ড দিন। স্ক্রিনে যে bcrypt hash আসবে সেটি কপি করুন। আসল পাসওয়ার্ড কাউকে বা GitHub-এ দেবেন না।

## ধাপ ৪ — Render-এ ফ্রি সার্ভিস তৈরি
1. https://render.com/ এ সাইন আপ করুন।
2. GitHub সংযুক্ত করুন এবং শুধু `jaman-survey-private-test` repository-তে অনুমতি দিন।
3. **New + → Blueprint** বেছে repository নির্বাচন করুন। অথবা **New + → Web Service** নিয়ে Node runtime, Build command `npm install`, Start command `npm start` দিন।
4. Plan হিসেবে **Free** নির্বাচন করুন।
5. Environment variables চাইলে যোগ করুন:
   - `DATABASE_URL` = Neon-এর connection string
   - `ADMIN_PASSWORD_HASH` = ধাপ ৩-এর bcrypt hash
   - `SESSION_SECRET` = কমপক্ষে ৩২ অক্ষরের এলোমেলো গোপন মান
   - `NODE_ENV` = `production`
   - `TRUST_PROXY` = `true`
   - `DATABASE_SSL` = `true`
6. Deploy শেষ হওয়া পর্যন্ত অপেক্ষা করুন। Render একটি `https://....onrender.com` ঠিকানা দেবে।

`SESSION_SECRET` বানাতে Node.js-এ চালাতে পারেন:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

এই মানটি শুধু Render-এর Environment-এ রাখবেন।

## ধাপ ৫ — পরীক্ষা
Render URL-এ গিয়ে:
- `/health` খুললে `{"ok":true}` আসবে।
- `/private/a4` লগইন ছাড়া খুললে `/login`-এ পাঠাবে।
- `/login`-এ সঠিক পাসওয়ার্ড দিলে `/private/admin` খুলবে।
- অ্যাডমিন থেকে A4 রিপোর্ট লিংক খুলবে।
- লগআউটের পর আবার `/private/a4` খুললে লগইন চাইবে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- Render Free ১৫ মিনিট নিষ্ক্রিয় থাকলে sleep করে; প্রথমবার খুলতে দেরি হতে পারে।
- Render-এর ফ্রি ওয়েব সার্ভিসের local filesystem অস্থায়ী; তাই সেশন PostgreSQL-এ রাখা হয়েছে।
- Neon Free-এর compute/storage/transfer সীমা আছে। ব্যবহার বাড়লে সীমা শেষ হতে পারে।
- অ্যাডমিন পেজটি এখন নিরাপদ প্রবেশদ্বার; পুরোনো পূর্ণ সেটিংস এডিটর, quotation/database management, customer data save, password reset, multi-admin ইত্যাদি এখনো যুক্ত হয়নি।
- A4 রিপোর্টের গণনা ব্রাউজারে হয়; এই সংস্করণে গ্রাহকের রিপোর্ট সার্ভারে সংরক্ষিত হয় না।
- কোনো hosting provider-এর free tier-কে গুরুত্বপূর্ণ/production data-র একমাত্র ভরসা করবেন না। নিয়মিত ব্যাকআপ রাখুন।
- আপনার লাইভ ওয়েবসাইট, domain, DNS বা hosting-এ এই প্যাকেজ নিজে থেকে কোনো পরিবর্তন করে না।

## স্থানীয়ভাবে চালানো
`.env.example` কপি করে `.env` করুন, উপরের মানগুলো বসান, তারপর:

```bash
npm install
npm start
```

ব্রাউজারে `http://localhost:3000/login` খুলুন।
