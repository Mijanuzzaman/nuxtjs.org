const bcrypt = require('bcryptjs');
const readline = require('readline');
const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
rl.question('নতুন শক্তিশালী অ্যাডমিন পাসওয়ার্ড লিখুন (কমপক্ষে ১২ অক্ষর): ', async p => {
  if (p.length < 12) { console.error('পাসওয়ার্ড কমপক্ষে ১২ অক্ষরের হতে হবে।'); rl.close(); process.exit(1); }
  console.log('\nADMIN_PASSWORD_HASH=' + await bcrypt.hash(p, 12));
  rl.close();
});
