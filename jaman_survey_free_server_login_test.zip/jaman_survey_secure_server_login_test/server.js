'use strict';
require('dotenv').config();
const express = require('express');
const session = require('express-session');
const PgSession = require('connect-pg-simple')(session);
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const crypto = require('crypto');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const IS_PROD = process.env.NODE_ENV === 'production';
const ADMIN_HASH = process.env.ADMIN_PASSWORD_HASH;
if (!ADMIN_HASH || !process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32 || !process.env.DATABASE_URL) {
  console.error('Set ADMIN_PASSWORD_HASH, DATABASE_URL and a 32+ character SESSION_SECRET in .env');
  process.exit(1);
}
if (IS_PROD && process.env.TRUST_PROXY !== 'false') app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));
app.use(express.json({ limit: '10kb' }));
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === 'false' ? false : { rejectUnauthorized: false },
  max: 5,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000
});
pool.on('error', err => console.error('PostgreSQL pool error:', err.message));

app.use(session({
  name: 'jaman.sid',
  store: new PgSession({ pool, tableName: 'user_sessions', createTableIfMissing: true, pruneSessionInterval: 15 * 60 }),
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: { httpOnly: true, secure: IS_PROD, sameSite: 'strict', maxAge: 30 * 60 * 1000, path: '/' }
}));
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 6, standardHeaders: 'draft-7', legacyHeaders: false, message: 'অনেকবার চেষ্টা হয়েছে। ১৫ মিনিট পরে আবার চেষ্টা করুন।' });

function csrfToken(req) {
  if (!req.session.csrf) req.session.csrf = crypto.randomBytes(32).toString('hex');
  return req.session.csrf;
}
function sameOrigin(req) {
  const origin = req.get('origin');
  if (!origin) return true; // same-origin form posts may omit Origin in some clients
  try { return new URL(origin).host === req.get('host'); } catch { return false; }
}
function csrfValid(req) {
  const a = Buffer.from(String(req.body._csrf || ''));
  const b = Buffer.from(String(req.session.csrf || ''));
  return a.length === b.length && a.length > 0 && crypto.timingSafeEqual(a, b);
}
function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin === true) return next();
  return res.redirect('/login');
}
app.get('/health', (_req, res) => res.json({ ok: true }));
app.get('/login', (req, res) => {
  if (req.session.isAdmin) return res.redirect('/private/admin');
  res.set('Cache-Control', 'no-store');
  res.send(`<!doctype html><html lang="bn"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>নিরাপদ অ্যাডমিন লগইন</title><style>body{font-family:system-ui,'Noto Sans Bengali',sans-serif;background:#eef3f5;margin:0;display:grid;min-height:100vh;place-items:center}.box{background:white;padding:28px;border-radius:16px;width:min(420px,90%);box-shadow:0 12px 40px #1232}input,button{box-sizing:border-box;width:100%;padding:13px;margin-top:12px;border-radius:9px;border:1px solid #ccd5dd;font:inherit}button{background:#0b2340;color:white;border:0;font-weight:700}.hint{color:#596879;font-size:14px}</style><div class="box"><h2>🔐 জামান সার্ভে — ব্যক্তিগত প্রবেশ</h2><p class="hint">শুধু অনুমোদিত অ্যাডমিন প্রবেশ করতে পারবেন।</p><form method="post" action="/login"><input type="hidden" name="_csrf" value="${csrfToken(req)}"><label for="password">অ্যাডমিন পাসওয়ার্ড</label><input id="password" name="password" type="password" autocomplete="current-password" required minlength="12"><button>নিরাপদে প্রবেশ করুন</button></form><p class="hint">সেশন ৩০ মিনিট নিষ্ক্রিয় থাকলে স্বয়ংক্রিয়ভাবে শেষ হবে।</p><a href="/">মূল ওয়েবসাইটে ফিরুন</a></div></html>`);
});
app.post('/login', loginLimiter, async (req, res) => {
  if (!sameOrigin(req) || !csrfValid(req)) return res.status(403).send('অনুরোধ যাচাই করা যায়নি। পেজ রিফ্রেশ করে আবার চেষ্টা করুন।');
  const pass = String(req.body.password || '');
  const ok = pass.length <= 200 && await bcrypt.compare(pass, ADMIN_HASH);
  if (!ok) { await new Promise(r => setTimeout(r, 400)); return res.status(401).send('পাসওয়ার্ড সঠিক নয়। <a href="/login">আবার চেষ্টা করুন</a>'); }
  req.session.regenerate(err => {
    if (err) return res.status(500).send('সেশন তৈরি করা যায়নি।');
    req.session.isAdmin = true;
    req.session.csrf = crypto.randomBytes(32).toString('hex');
    req.session.save(e => e ? res.status(500).send('সেশন সংরক্ষণ ব্যর্থ।') : res.redirect('/private/admin'));
  });
});
app.get('/private/admin', requireAdmin, (req, res) => {
  res.set('Cache-Control', 'no-store, private');
  res.send(`<!doctype html><html lang="bn"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>অ্যাডমিন কন্ট্রোল প্যানেল</title><style>body{font-family:system-ui,'Noto Sans Bengali',sans-serif;background:#f2f5f7;color:#183047;margin:0;padding:24px}.wrap{max-width:850px;margin:auto;background:white;padding:24px;border-radius:16px;box-shadow:0 10px 32px #1231}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}.card{padding:18px;border:1px solid #dce5eb;border-radius:12px}a,button{display:inline-block;background:#0b2340;color:white;text-decoration:none;border:0;padding:11px 15px;border-radius:8px;font:inherit;cursor:pointer}.muted{color:#647586}.warn{background:#fff7e5;padding:12px;border-radius:9px}</style><div class="wrap"><h1>জামান সার্ভে — অ্যাডমিন কন্ট্রোল প্যানেল</h1><p class="muted">সার্ভার যাচাইকৃত অ্যাডমিন সেশন সক্রিয়।</p><div class="grid"><div class="card"><h3>📄 A4 রিপোর্ট</h3><p>চার বাহু ও দুই কর্ণ দিয়ে A4 জরিপ রিপোর্ট তৈরি করুন।</p><a href="/private/a4">A4 রিপোর্ট খুলুন</a></div><div class="card"><h3>⚙ অ্যাডমিন কন্ট্রোল</h3><p>এই নিরাপদ প্রবেশদ্বারটি সার্ভার-সুরক্ষিত। ওয়েবসাইটের অন্যান্য সেটিংস/ডেটাবেস ব্যবস্থাপনা পরবর্তী সংযোগ ধাপে যুক্ত হবে।</p></div></div><p class="warn">নিরাপত্তা: এই প্যানেল ও A4 রিপোর্ট সার্ভার সেশন ছাড়া পরিবেশন করা হয় না। বর্তমান A4 হিসাব ব্রাউজারে চলে; গ্রাহকের তথ্য সার্ভারে সংরক্ষণ করা হয় না।</p><form method="post" action="/logout"><input type="hidden" name="_csrf" value="${csrfToken(req)}"><button>লগআউট</button></form><p><a href="/">পাবলিক ওয়েবসাইট দেখুন</a></p></div></html>`);
});
app.get('/private/a4', requireAdmin, (_req, res) => {
  res.set({ 'Cache-Control': 'no-store, private', 'X-Robots-Tag': 'noindex, nofollow' });
  res.sendFile(path.join(ROOT, 'private', 'a4-report.html'));
});
app.post('/logout', requireAdmin, (req, res) => {
  if (!sameOrigin(req) || !csrfValid(req)) return res.status(403).send('অনুরোধ যাচাই করা যায়নি।');
  req.session.destroy(() => res.clearCookie('jaman.sid', { path: '/', httpOnly: true, secure: IS_PROD, sameSite: 'strict' }).redirect('/login'));
});
// Public folder contains no A4 report source or admin panel markup.
app.use(express.static(path.join(ROOT, 'public'), { index: 'index.html', etag: true, maxAge: IS_PROD ? '1h' : 0 }));
app.use((_req, res) => res.status(404).send('পৃষ্ঠা পাওয়া যায়নি।'));
const server = app.listen(PORT, '0.0.0.0', () => console.log(`Jaman Survey test server listening on port ${PORT}`));

async function shutdown() {
  server.close(async () => { await pool.end().catch(() => {}); process.exit(0); });
  setTimeout(() => process.exit(1), 10000).unref();
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
